package com.ffautopilot.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.content.Context;

public class ControlAccessibilityService extends AccessibilityService {
    public static volatile ControlAccessibilityService instance;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Intentionally do not inspect event content. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static boolean isEnabled() {
        return instance != null;
    }

    public boolean runSafeTapTest() {
        if (Build.VERSION.SDK_INT < 24 || getRootInActiveWindow() == null) return false;
        CharSequence pkg = getRootInActiveWindow().getPackageName();
        if (pkg == null || !getPackageName().contentEquals(pkg)) return false;
        Rect bounds = new Rect();
        getRootInActiveWindow().getBoundsInScreen(bounds);
        float x = bounds.centerX();
        float y = bounds.centerY();
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 80);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(gesture, null, new Handler(Looper.getMainLooper()));
    }
}
