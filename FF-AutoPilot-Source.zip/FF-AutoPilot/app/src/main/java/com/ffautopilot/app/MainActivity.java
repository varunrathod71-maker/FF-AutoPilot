package com.ffautopilot.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private TextView result;
    private int bg = Color.rgb(13, 17, 24);
    private int panel = Color.rgb(25, 32, 43);
    private int accent = Color.rgb(102, 232, 163);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root);

        TextView eyebrow = text("PRIVATE • LOCAL-ONLY", 12, accent, true);
        root.addView(eyebrow);
        TextView title = text("FF AutoPilot", 30, Color.WHITE, true);
        LinearLayout.LayoutParams titleLp = params(-1, -2); titleLp.topMargin = dp(7); root.addView(title, titleLp);
        TextView subtitle = text("Android automation test bench", 15, Color.rgb(173, 184, 200), false);
        LinearLayout.LayoutParams subLp = params(-1, -2); subLp.topMargin = dp(5); root.addView(subtitle, subLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16), dp(16), dp(16), dp(16)); card.setBackgroundColor(panel);
        LinearLayout.LayoutParams cardLp = params(-1, -2); cardLp.topMargin = dp(24); root.addView(card, cardLp);
        card.addView(text("ACCESSIBILITY STATUS", 12, accent, true));
        status = text("Checking…", 16, Color.WHITE, true);
        LinearLayout.LayoutParams statusLp = params(-1, -2); statusLp.topMargin = dp(9); card.addView(status, statusLp);
        Button settings = button("Open Accessibility Settings");
        LinearLayout.LayoutParams settingsLp = params(-1, -2); settingsLp.topMargin = dp(14); card.addView(settings, settingsLp);
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        TextView section = text("SAFE TEST", 12, accent, true);
        LinearLayout.LayoutParams secLp = params(-1, -2); secLp.topMargin = dp(24); root.addView(section, secLp);
        TextView description = text("The test gesture is allowed only while this app is the active screen. It does not control other apps, inspect screen text, connect to the internet, or store personal data.", 14, Color.rgb(193, 201, 214), false);
        LinearLayout.LayoutParams descLp = params(-1, -2); descLp.topMargin = dp(9); root.addView(description, descLp);
        Button test = button("Run safe tap test");
        LinearLayout.LayoutParams testLp = params(-1, -2); testLp.topMargin = dp(14); root.addView(test, testLp);
        test.setOnClickListener(v -> {
            if (!ControlAccessibilityService.isEnabled()) {
                result.setText("First enable “FF AutoPilot test controls” in Accessibility Settings.");
                return;
            }
            ControlAccessibilityService service = ControlAccessibilityService.instance;
            if (service == null) {
                result.setText("Service is not connected yet. Return here after enabling it.");
            } else {
                boolean sent = service.runSafeTapTest();
                result.setText(sent ? "Test gesture sent inside FF AutoPilot." : "Test not sent. Keep FF AutoPilot in the foreground and try again.");
            }
        });
        result = text("No test run yet.", 14, Color.WHITE, false);
        LinearLayout.LayoutParams resultLp = params(-1, -2); resultLp.topMargin = dp(12); root.addView(result, resultLp);

        TextView safety = text("Safety by design", 18, Color.WHITE, true);
        LinearLayout.LayoutParams safetyLp = params(-1, -2); safetyLp.topMargin = dp(28); root.addView(safety, safetyLp);
        addBullet("No INTERNET permission");
        addBullet("No passwords, OTPs, or account data");
        addBullet("No background taps or hidden automation");
        addBullet("Visible, user-started test only");
        TextView footer = text("Prototype v0.1.0 • This is not a Free Fire rank bot. Game automation may violate game rules and risk an account.", 12, Color.rgb(140, 153, 171), false);
        LinearLayout.LayoutParams footLp = params(-1, -2); footLp.topMargin = dp(25); root.addView(footer, footLp);
        setContentView(scroll);
    }

    private void addBullet(String s) {
        TextView t = text("•  " + s, 14, Color.rgb(193, 201, 214), false);
        LinearLayout.LayoutParams lp = params(-1, -2); lp.topMargin = dp(8); root.addView(t, lp);
    }

    private void refreshStatus() {
        if (status == null) return;
        status.setText(ControlAccessibilityService.isEnabled() ? "Enabled — test service available" : "Not enabled");
        status.setTextColor(ControlAccessibilityService.isEnabled() ? accent : Color.rgb(255, 190, 110));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextColor(Color.rgb(10, 20, 17)); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        return b;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
