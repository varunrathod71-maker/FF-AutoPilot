# FF AutoPilot — privacy-first Android prototype

Version 0.1.0 is a native Android app scaffold designed for an Android-only build workflow.

## What this prototype does
- Displays whether its Accessibility test service is connected.
- Provides a button to open Android Accessibility Settings.
- Has a user-started tap test restricted to when FF AutoPilot itself is the active app.
- Requests no INTERNET permission and does not read window text or store personal data.

## Important limitations
- This is **not** a Free Fire bot and does not automate gameplay.
- The Accessibility service requires explicit user opt-in in Android settings.
- Accessibility behavior varies by Android version and OEM.
- Do not use automation to enter financial credentials or approve transactions.

## Build an APK using GitHub Actions
1. Create a new empty GitHub repository.
2. Upload the contents of this folder (not the outer folder itself) to the repository.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. The workflow named **Build FF AutoPilot APK** builds a debug APK.
5. Open the completed workflow run, scroll to **Artifacts**, and download `FF-AutoPilot-debug-apk`.
6. Extract the ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/file manager; only do so for the APK you built from this source.

## Local build
Use Android Studio / Android SDK and Gradle 8.9 with JDK 17 or 21, then run `gradle assembleDebug`.
